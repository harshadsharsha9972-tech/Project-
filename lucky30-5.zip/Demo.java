/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Node {
    int data;    // the value
    Node next;   // reference to the next node
    Node(int data) { this.data = data; }
}

public class Demo {
    public static void main(String[] args) {
        Node n1 = new Node(10);
        Node n2 = new Node(20);
        Node n3 = new Node(30);

        n1.next = n2;  // link 10 -> 20
        n2.next = n3;  // link 20 -> 30
        Node head = n1;

        // traversal
        for (Node cur = head; cur != null; cur = cur.next) {
            System.out.print(cur.data + " -> ");
        }
        System.out.println("null");

        int count = 0, sum = 0;
        Node cur = head;
        while (cur != null) {
            count++;
            sum += cur.data;
            cur = cur.next;
        }
        System.out.println("Nodes: " + count + ", Sum: " + sum);
    }
}
