/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Student{
     int roolNo;
     String name;
     private double marks;
 
     static int count = ೦;
     student()
      student (int rollNo, String name, double marks){
          this.rollNo = roll no ;
          this.name = name ;
          this.marks = marks;
          count++ ;
      }
      
        
      public void setMarks(double marks) 
       {
       if (marks >= ೦ && marks <= 100) this.marks = marks;
  
       }
     public double getMarks (){
            return marks;
        }
       public char getGrade (){
     if(marks >= 75) return 'A';
     if(marks >= 50) return ' B';
      return 'C';
      
      }
       public void display(){
        System.out.println(roolNo + " " + name + " " + marks + " " + getGrade ());
       }
        public static void main(String[] args){
      Student s1 = new Student(roolNo: 121, name: "kumar",marks: 88 );
      Student  s2 = new Student(roolNo: 122, name: "pavan" , marks: 68 );
      Student s3 = new Student(roolNo:123, name:" Manthu" ,marks: 96 );
      Student s4 = new Student(roolNo: 124, name: "uma", marks: 50);
      s1.display();
      s2. display ();
      s3. display ();
      S4. display ();
       System.out.println(count);
    }
}
     